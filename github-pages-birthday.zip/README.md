# Birthday Website — GitHub Pages

## Publish it
1. Create a repository on GitHub (for example, `birthday-website`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site; the public URL will appear in the Pages section.

## Notes
- The photos embedded in the HTML are included already.
- The page references `song.mp3` for background music, but that audio file was not included in the upload. To enable the music player, add your own `song.mp3` to the repository root.
- The page currently includes the names/text present in the original file; edit them in `index.html` if needed.
